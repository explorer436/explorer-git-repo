# DNA Setup Scripts

### [Linux Install](https://git.forge.lmig.com/projects/USCM-DNA-BLUEPRINT/repos/dna-setup-scripts/browse/linux)

### [Windows Install](https://git.forge.lmig.com/projects/USCM-DNA-BLUEPRINT/repos/dna-setup-scripts/browse/windows)