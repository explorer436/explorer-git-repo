<#
.SYNOPSIS
Run As Administrator

.DESCRIPTION
Check that this script is running as Administrator.
If its not then try to as Administrator

.EXAMPLE
Import-Module "$(split-path -parent $MyInvocation.MyCommand.Definition)\..\lib\admin.psm1" -Force;

if ( RunAsAdmin($MyInvocation.MyCommand.Definition) ) {
    Write-Output "I'm an Admin!!";
}
else {
    Write-Output "Admin not allowed";
}

Pause;

#>

function RunAsAdmin {
    param( 
        [string]$script
    )
    begin {
        if ( $script.Length -eq 0 ) {
            return $false;
        }
    }
    process {
        # Get the ID and security principal of the current user account
        $myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
        $myWindowsPrincipal = new-object System.Security.Principal.WindowsPrincipal($myWindowsID);
 
        # Get the security principal for the Administrator role
        $adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;
 
        # Check to see if we are currently running "as Administrator"
        if ($myWindowsPrincipal.IsInRole($adminRole)) {
            # We are running "as Administrator"
            return $true;
        }
        else {
            # We are not running "as Administrator" - so relaunch as administrator
        
            try {   
                $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
                $newProcess.Arguments = $script;
                $newProcess.Verb = "runas";
                
                [System.Diagnostics.Process]::Start($newProcess);
                
                Write-Host "Spawning Administrator Powershell ..."
                exit;
            }
            catch [System.ComponentModel.Win32Exception], [System.Management.Automation.MethodInvocationException] {
            }

            return $false;
        }
    }
    end {}
}
