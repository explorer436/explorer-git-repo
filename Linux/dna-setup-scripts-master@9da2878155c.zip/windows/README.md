# DNA Linux Slice Setup Script

This script can be used to install some of the development tools on the Windows 10 Dev Network (with docker) Slices. 

To install this script, run the following commands below.

1. Request a [DevNet-Win10 x64 with Docker](https://lcd.lmig.com/vcac/)
    1. ![linux](../images/windows.png)
1. Download script from [BitBucket](https://git.forge.lmig.com/rest/api/latest/projects/USCM-DNA-BLUEPRINT/repos/dna-setup-scripts/archive?format=zip)
2. Extract, cd into windows, and move script to Downloads, Documents, or Desktop
4. Run the `install.ps1` script as administrator.
5. Select 1 to start install
6. You will be prompted for your N number, your first and last name, and your email.
7. The install script will take 10-15 minutes to finish.

The following packages and tools get installed using this script:

- Git
- NodeJS (v10.14.2)
- nvm
- jdk8
- Gradle (v5.0)
- Yarn
- Eclipse (v4.9)
- Visual Code Studio
- Python
