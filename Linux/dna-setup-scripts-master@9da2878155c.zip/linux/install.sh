#!/bin/bash

YUM_CONF="/etc/yum.conf";
YUM_PROXY_CONFIG="proxy=http://localhost:3128";
CURL_PROXY="http://localhost:3128";
CNTLM_CONF="/etc/cntlm.conf";
CNTLM_BACKUP_CONF="/etc/cntlm.conf.bak";
ECLIPSE_DIR="/opt/eclipse";
INTELLJI_DIR="/opt/idea-IC-182.4129.33";
DOCKER_SERVICE_DIR="/etc/systemd/system/docker.service.d";

# Function to handle error messages
already_installed () {
   echo "Skipping - $1 is already installed"
}


# Configure Yum to work on proxy
# Check to see if configuration is already set
echo "Starting proxy config"
if grep --quiet $YUM_PROXY_CONFIG $YUM_CONF; then
    already_installed "Proxy Config"    
else
    echo "Configuring Yum Proxy";
    echo "enableProxy=1" >> $YUM_CONF
    echo $YUM_PROXY_CONFIG >> $YUM_CONF
fi

# Download dev tools to be installed
echo "Downloading dev tools";
DOWNLOAD_SOURCE_PATH="http://pkc9pdc.lmig.com/public-repository/developerHelper/LIN/developer-multi-tool"
DMG_NAME="developer-multi-tool-1.0.1-1.x86_64.rpm"

# Prompt for N number
if [ "$1" != "" ]; then
   NNUMBER=$1
else
   read -p "Enter your N number: " NNUMBER
fi

printf '%s\n' * $'\n'

# Set Download directory
DOWNLOAD_DIR="/home/$NNUMBER/Downloads"


if [ ! -f $DOWNLOAD_DIR/$DMG_NAME ]
then
	curl -o $DOWNLOAD_DIR/$DMG_NAME -k $DOWNLOAD_SOURCE_PATH/$DMG_NAME
fi

if rpm -qa developer-multi-tool; then
     already_installed "Dev Tools"     
else 
     # Install directory
     # /opt/developer-multi-tool/developer-multi-tool/
     echo "Installing dev tools":
     sudo rpm -i $DOWNLOAD_DIR/$DMG_NAME --nodeps
     sudo chmod -R 777 /opt/developer-multi-tool/ 
fi

if grep --quiet "# PassNTLMv2" $CNTLM_CONF; then
    # Configure CNTLM
    echo "Configuring CNTLM"
    systemctl stop cntlm

    pkill -9 -x cntlm
    pkill -9 -x cntlmd

    cp -n $CNTLM_CONF $CNTLM_BACKUP_CONF
    rm -f $CNTLM_CONF

    echo
    echo "Auth      NTLMv2" > $CNTLM_CONF
    echo "Username  $NNUMBER" >> $CNTLM_CONF
    echo "Domain    lm" >> $CNTLM_CONF
    echo "Proxy     www-proxy.lmig.com:80" >> $CNTLM_CONF
    echo "Listen    3128" >> $CNTLM_CONF
    echo "NoProxy   localhost, 127.0.0.*, 10.*" >> $CNTLM_CONF
    echo "Enter your ($NNUMBER) account password:"
    cntlm -u $NNUMBER -d lm -H | grep PassNTLMv2 | sed 's/#.*$//' >> $CNTLM_CONF

    systemctl restart cntlm

    export all_proxy=http://localhost:3128/
    export ftp_proxy=http://localhost:3128/
    export http_proxy=http://localhost:3128/
    export https_proxy=http://localhost:3128/
    export no_proxy="localhost,127.0.0.1,localaddress,*.lmig.com"
    export ALL_PROXY=http://localhost:3128/
    export FTP_PROXY=http://localhost:3128/
    export HTTP_PROXY=http://localhost:3128/
    export HTTPS_PROXY=http://localhost:3128/
    export NO_PROXY="localhost,127.0.0.1,localaddress,*.lmig.com"

cat <<EOF > /etc/profile.d/cntlm_proxy.sh
     export all_proxy=http://localhost:3128/
     export ftp_proxy=http://localhost:3128/
     export http_proxy=http://localhost:3128/
     export https_proxy=http://localhost:3128/
     export no_proxy="localhost,127.0.0.1,localaddress,*.lmig.com"
     export ALL_PROXY=http://localhost:3128/
     export FTP_PROXY=http://localhost:3128/
     export HTTP_PROXY=http://localhost:3128/
     export HTTPS_PROXY=http://localhost:3128/
     export NO_PROXY="localhost,127.0.0.1,localaddress,*.lmig.com"
EOF

     chown root:root /etc/profile.d/cntlm_proxy.sh
     chmod 644 /etc/profile.d/cntlm_proxy.sh

     systemctl enable cntlm

     . /etc/profile
     sleep 5

else
    already_installed "CNTLM"
fi

# Checking to see if Git in istalled
if yum list installed "git" >/dev/null 2>&1; then
     #echo "Skipping - Git is already installed"
     already_installed "Git"
else
     # Install Git
     echo "Installing Git"
     sudo yum install -y git
fi

# Checking to see if NodeJS is installed
if yum list installed "nodejs" >/dev/null 2>&1; then
     already_installed "NodeJS"     
else
     # Install NodeJS
     echo "Installing NodeJS"
     curl -x $CURL_PROXY -sL https://rpm.nodesource.com/setup_8.x | bash -
     sudo yum install -y nodejs
     npm config set registry https://repo.forge.lmig.com/content/repositories/ets-npm
fi

# Checking to see if Yarn is installed
if yum list installed "yarn" >/dev/null 2>&1; then
     already_installed "Yarn"     
else
     # Install Git
     echo "Installing Yarn"
     curl -x $CURL_PROXY -sL https://dl.yarnpkg.com/rpm/yarn.repo | sudo tee /etc/yum.repos.d/yarn.repo
     sudo yum install -y yarn
fi

# Check to see if Python is installed
if yum list installed "python-pip" >/dev/null 2>&1; then
     already_installed "Python"
else
    sudo yum install -y python-pip
fi

# Check to see if java-1.8.0-openjdk-devel.x86_64 is installed
if yum list installed "java-1.8.0-openjdk-devel.x86_64" >/dev/null 2>&1; then
     already_installed "java-1.8.0-openjdk-devel.x86_64"
else
    sudo yum install -y java-1.8.0-openjdk-devel.x86_64
fi

# Check to see if Docker is installed
if yum list installed "docker-engine" >/dev/null 2>&1; then
     already_installed "Docker"
else
     # Install Docker
     echo "Installing Docker"
     sudo wget -e use_proxy=yes -e http_proxy=$CURL_PROXY "http://yum.oracle.com/public-yum-ol7.repo" -O /etc/yum.repos.d/public-yum-ol7.repo
     sudo yum-config-manager --enable ol7_latest,ol7_UEKR4,ol7_addons
     sudo yum update -y
     sudo yum install -y docker-engine
     sudo chmod 666 /var/run/docker.sock
     sudo systemctl start docker
     sudo systemctl enable docker
     systemctl status docker

    sudo pip --proxy $CURL_PROXY install docker-compose
fi

# Check to see if Docker Proxy settings are set for DTR
if [ ! -d $DOCKER_SERVICE_DIR/http-proxy.conf ]; then
    echo "Installing Docker Proxy Settings"
    echo "Setting Docker http proxy"
    echo "[Service]" >> "$DOCKER_SERVICE_DIR/http-proxy.conf"
    echo "Environment="HTTP_PROXY=http://localhost:3128/" "NO_PROXY=*.lmig.com"" >> "$DOCKER_SERVICE_DIR/http-proxy.conf"

    sudo systemctl daemon-reload
    sudo systemctl restart docker
    sudo chmod 666 /var/run/docker.sock

else
    already_installed "Docker HTTP Proxy Settings"
fi

# Check to see if Docker Proxy settings are set for DTR
if [ ! -d $DOCKER_SERVICE_DIR/https-proxy.conf ]; then\

    echo "Setting Docker https proxy"
    echo "[Service]" >> "$DOCKER_SERVICE_DIR/https-proxy.conf"
    echo "Environment="HTTPS_PROXY=http://localhost:3128/" "NO_PROXY=*.lmig.com"" >> "$DOCKER_SERVICE_DIR/https-proxy.conf"

    sudo systemctl daemon-reload
    sudo systemctl restart docker
    sudo chmod 666 /var/run/docker.sock

else
    already_installed "Docker HTTPS Proxy Settings"
fi

# Check to see if Visual Code Studio is installed
if yum list installed "code" >/dev/null 2>&1; then
     already_installed "Visual Code Studio"
else
     # Install Visual Code Studio
     echo "Installing Visual Code Studio"
     sudo rpm -httpproxy $CURL_PROXY --import https://packages.microsoft.com/keys/microsoft.asc
     sudo sh -c 'echo -e "[code]\nname=Visual Studio Code\nbaseurl=https://packages.microsoft.com/yumrepos/vscode\nenabled=1\ngpgcheck=1\ngpgkey=https://packages.microsoft.com/keys/microsoft.asc" > /etc/yum.repos.d/vscode.repo'
     yum check-update
     sudo yum install -y code

     if grep --quiet "Categories=GNOME;Application;Development" /usr/share/applications/code.desktop; then
         already_installed "Visual Code Studio Config"
     else
        echo "Configuring Visual Code Studio";
        sudo rm /usr/share/applications/code.desktop
        echo "[Desktop Entry]" >> "/usr/share/applications/code.desktop"
	    echo "Name=Visual Studio Code" >> "/usr/share/applications/code.desktop"
        echo "Comment=Code Editing. Redefined." >> "/usr/share/applications/code.desktop"
        echo "GenericName=Text Editor" >> "/usr/share/applications/code.desktop"
        echo "Exec=/usr/share/code/code --unity-launch %F" >> "/usr/share/applications/code.desktop"
        echo "Icon=code" >> "/usr/share/applications/code.desktop"
        echo "Type=Application" >> "/usr/share/applications/code.desktop"
        echo "StartupNotify=true" >> "/usr/share/applications/code.desktop"
        echo "StartupWMClass=Code" >> "/usr/share/applications/code.desktop"
        echo "Categories=GNOME;Application;Development;" >> "/usr/share/applications/code.desktop"
        echo "MimeType=text/plain;inode/directory;" >> "/usr/share/applications/code.desktop"
        echo "Actions=new-empty-window;" >> "/usr/share/applications/code.desktop"
        echo "Keywords=vscode;" >> "/usr/share/applications/code.desktop"

        echo "[Desktop Action new-empty-window]" >> "/usr/share/applications/code.desktop"
        echo "Name=New Empty Window" >> "/usr/share/applications/code.desktop"
        echo "Exec=/usr/share/code/code --new-window %F" >> "/usr/share/applications/code.desktop"
        echo "Icon=code" >> "/usr/share/applications/code.desktop"
     fi
fi

# Check if Eclipse is installed already
if [ ! -d $ECLIPSE_DIR ]; then
    # Start Eclipse install
    sudo mkdir $ECLIPSE_DIR

    # Download files
    echo "Downloading Eclipse install files";
    sudo wget -e use_proxy=yes -e http_proxy=$CURL_PROXY http://ftp.fau.de/eclipse/technology/epp/downloads/release/oxygen/3a/eclipse-jee-oxygen-3a-linux-gtk-x86_64.tar.gz -O $ECLIPSE_DIR"/eclipse-jee-oxygen-3a-linux-gtk-x86_64.tar.gz"
    
    echo "Installing Eclipse";
    sudo tar -xvf $ECLIPSE_DIR/eclipse-jee-oxygen-3a-linux-gtk-x86_64.tar.gz -C $ECLIPSE_DIR
    sudo mv $ECLIPSE_DIR/eclipse $ECLIPSE_DIR/oxygen

    echo "Cleaning up Eclipse install";
    sudo rm -R $ECLIPSE_DIR/eclipse-jee-oxygen-3a-linux-gtk-x86_64.tar.gz
    sudo ln -s /opt/eclipse/oxygen/eclipse /usr/local/bin/eclipse

    echo "Configuring Eclipse";

    echo "[Desktop Entry]" >> "/usr/share/applications/eclipse.desktop"
    echo "Name=Eclipse Oxygen" >> "/usr/share/applications/eclipse.desktop"
    echo "Exec=/usr/local/bin/eclipse" >> "/usr/share/applications/eclipse.desktop"
    echo "Terminal=false" >> "/usr/share/applications/eclipse.desktop"
    echo "Comment=Eclipse Oxygen IDE" >> "/usr/share/applications/eclipse.desktop"
    echo "Type=Application" >> "/usr/share/applications/eclipse.desktop"
    echo "Encoding=UTF-8" >> "/usr/share/applications/eclipse.desktop"
    echo "Icon=/opt/eclipse/oxygen/icon.xpm" >> "/usr/share/applications/eclipse.desktop"
    echo "Categories=GNOME;Application;Development;" >> "/usr/share/applications/eclipse.desktop"
    echo "StartupNotify=true" >> "/usr/share/applications/eclipse.desktop"
else
    already_installed "Eclipse"
fi

# Check if Idea Intellji is installed
if [ ! -d $INTELLJI_DIR ]; then
    echo "Downloading Intellji";
    sudo mkdir $INTELLJI_DIR
    sudo wget -e use_proxy=yes -e https_proxy=$CURL_PROXY https://download.jetbrains.com/idea/ideaIC-2018.2.2.tar.gz -O $INTELLJI_DIR/ideaIC-2018.2.2.tar.gz
    sudo tar xfz $INTELLJI_DIR/ideaIC-2018.2.2.tar.gz -C $INTELLJI_DIR
    sudo rm -R $INTELLJI_DIR/ideaIC-2018.2.2.tar.gz
    sudo ln -s $INTELLJI_DIR/idea-IC-182.4129.33 /usr/local/bin/idea-IC-182.4129.33

    echo "Configuring Intellji";

    echo "[Desktop Entry]" >> "/usr/share/applications/Intellji.desktop"
    echo "Name=IntelliJ IDEA" >> "/usr/share/applications/Intellji.desktop"
    echo 'Exec="/usr/local/bin/idea-IC-182.4129.33/bin/idea.sh" %f' >> "/usr/share/applications/Intellji.desktop"
    echo "Terminal=false" >> "/usr/share/applications/Intellji.desktop"
    echo "Comment=IntelliJ IDEA" >> "/usr/share/applications/Intellji.desktop"
    echo "Type=Application" >> "/usr/share/applications/Intellji.desktop"
    echo "Icon=/usr/local/bin/idea-IC-182.4129.33/bin/idea.png" >> "/usr/share/applications/Intellji.desktop"
    echo "Categories=GNOME;Application;Development;" >> "/usr/share/applications/Intellji.desktop"
    echo "StartupNotify=true" >> "/usr/share/applications/Intellji.desktop"
else 
    already_installed "Intellji"
fi

