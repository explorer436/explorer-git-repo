# DNA Linux Slice Setup Script

This script can be used to install some of the development tools on the Oracle Linux 7 Slices. 

To install this script, run the following commands below.

1. Request a [Linux Slice](https://lcd.lmig.com/vcac/)
    1. ![linux](../images/linux.png)
1. Download script from [BitBucket](https://git.forge.lmig.com/rest/api/latest/projects/USCM-DNA-BLUEPRINT/repos/dna-setup-scripts/archive?format=zip)
2. Extract, cd into linux, and move script to Downloads, Documents, or Desktop
3. Change the permissions of the script so that it executable. EX: `chmod 777 dna_linux_setup.sh`
    1. This script can be deleted once the installation is complete.
4. Run the script with the following command, `sudo ./dna_linux_setup.sh`
    1. Ensure that you run the script with `sudo` or you may run into permission issues.
5. You will be prompted for your N number and your enterprise password.
6. The install script will take 5-10 minutes to finish.

The following packages and tools get installed using this script:

- Linux Developer tools
- CNTLM (Configured)
- Git
- NodeJS
- Yarn
- Python
- Docker
- Docker-Compose
- IntelliJ IDEA
    - `The license key will need to be installed`
- Visual Code Studio
- Eclipse

The following packages and tools can be installed but are not included in this script at this time:

- Slack

### Known problem areas

- Running docker commands result in:
    ```
    Got permission denied while trying to connect to the Docker daemon socket at unix:///var/run/docker.sock: Get http://%2Fvar%2Frun%2Fdocker.sock/v1.37/services: dial unix /var/run/docker.sock: connect: permission denied
    ```
    1. Run docker commands with `Sudo` OR
    2. `sudo chmod 666 /var/run/docker.sock`
        - This command will fix the docker permissions
